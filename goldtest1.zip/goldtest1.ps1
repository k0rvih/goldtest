Configuration goldtest
{
  param (
  $iistriger
  )
    Node localhost
  {

    LocalConfigurationManager

    {
      ConfigurationModeFrequencyMins = 15
      ConfigurationMode = "ApplyAndAutoCorrect"    
    }

    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure = $iistriger
      Name = �Web-Server�
    }
    Service XblAuthManager {
      Name = "XblAuthManager"
      StartupType = "Disabled"
      State = "Stopped"
      }
   Service XblGameSave {
      Name = "XblGameSave"
      StartupType = "Disabled"
      State = "Stopped"
      }
  }
}