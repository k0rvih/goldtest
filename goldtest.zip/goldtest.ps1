Configuration goldtest
{
  param (
  $MachineName, 
  [string]$iistriger
  )

  Node $MachineName
  {
    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure = $iistriger
      Name = �Web-Server�
    }
  }
}