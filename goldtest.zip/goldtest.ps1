Configuration goldtest
{
  param (
  $MachineName,
  
  [Parameter(Mandatory=$true)]
  [ValidateSet("Absent","Present")]
  [string]
  $iistriger
  )

  Node $MachineName
  {
    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure = $iistriger
      Name = �Web-Server�
    }
  }
}