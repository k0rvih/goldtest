Configuration goldtest
{
  param (
  $MachineName
  )

  Node $MachineName
  {
    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure = 'Absent'
      Name = �Web-Server�
    }
  }
}